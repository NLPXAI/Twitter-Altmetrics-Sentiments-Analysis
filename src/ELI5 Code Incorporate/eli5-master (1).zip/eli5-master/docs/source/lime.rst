:orphan: Docs are moved

See :ref:`eli5-lime`.