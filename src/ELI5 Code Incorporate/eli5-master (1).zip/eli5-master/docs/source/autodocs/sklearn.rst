eli5.sklearn
============

eli5.sklearn.explain_prediction
-------------------------------

.. automodule:: eli5.sklearn.explain_prediction
    :members:


eli5.sklearn.explain_weights
----------------------------

.. automodule:: eli5.sklearn.explain_weights
    :members:


eli5.sklearn.unhashing
----------------------

.. automodule:: eli5.sklearn.unhashing
    :members:


eli5.sklearn.permutation_importance
-----------------------------------

.. automodule:: eli5.sklearn.permutation_importance
    :members:
