eli5.permutation_importance
===========================

.. note::
    See also: :class:`~.PermutationImportance`

.. automodule:: eli5.permutation_importance
    :members:

