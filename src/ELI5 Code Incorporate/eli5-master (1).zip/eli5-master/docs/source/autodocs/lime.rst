.. module:: eli5.lime

eli5.lime
=========

eli5.lime.lime
--------------

.. automodule:: eli5.lime.lime
    :members:

eli5.lime.samplers
------------------

.. automodule:: eli5.lime.samplers
    :members:
    :undoc-members:


eli5.lime.textutils
-------------------

.. automodule:: eli5.lime.textutils
    :members:
