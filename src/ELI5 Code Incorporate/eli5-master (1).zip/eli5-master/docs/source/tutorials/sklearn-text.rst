.. _text-processing-tutorial:

.. note::

    This tutorial is intended to be run in an IPython notebook.
    It is also available as a notebook file here_.

.. _here: https://github.com/TeamHG-Memex/eli5/blob/master/notebooks/Debugging%20scikit-learn%20text%20classification%20pipeline.ipynb

.. include:: ../_notebooks/debug-sklearn-text.rst
