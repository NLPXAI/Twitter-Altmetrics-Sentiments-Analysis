.. _lime-tutorial:

.. note::

    This tutorial can be run as an IPython notebook_.

.. _notebook: https://github.com/TeamHG-Memex/eli5/blob/master/notebooks/TextExplainer.ipynb

.. include:: ../_notebooks/text-explainer.rst
