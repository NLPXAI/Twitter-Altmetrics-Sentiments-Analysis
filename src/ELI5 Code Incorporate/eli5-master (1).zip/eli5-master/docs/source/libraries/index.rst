.. _supported-libraries:

Supported Libraries
===================

.. toctree::
   :maxdepth: 1

   sklearn
   xgboost
   lightgbm
   catboost
   lightning
   sklearn_crfsuite
   keras

