# -*- coding: utf-8 -*-
WEIGHTS = (
    'transition_features',
    'targets',
    'feature_importances',
    'decision_tree'
)
INFO = ('method', 'description',)
ALL = INFO + WEIGHTS
